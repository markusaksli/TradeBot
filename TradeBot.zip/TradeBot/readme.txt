JDK 11 or higher is required to run the bot.

Edit config.txt to change the parameters of the bot.